// routes/profileRoute.js
const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const InvestorProfile = require('../models/InvestorProfile');
const FounderProfile = require('../models/FounderProfile');
const User = require('../models/User');

// Create or update investor profile
router.post('/investor', auth, async (req, res) => {
    try {
        if (req.user.role !== 'investor') return res.status(403).send('Forbidden');
        const data = { user: req.user._id, ...req.body };
        let profile = await InvestorProfile.findOne({ user: req.user._id });
        if (profile) {
            profile = await InvestorProfile.findOneAndUpdate({ user: req.user._id }, data, { new: true });
        } else {
            profile = new InvestorProfile(data);
            await profile.save();
        }
        req.user.isProfileComplete = true;
        await req.user.save();
        res.json(profile);
    } catch (err) { res.status(500).send('Server error'); }
});

// Create or update founder profile
router.post('/founder', auth, async (req, res) => {
    try {
        if (req.user.role !== 'founder') return res.status(403).send('Forbidden');
        const data = { user: req.user._id, ...req.body };
        let profile = await FounderProfile.findOne({ user: req.user._id });
        if (profile) {
            profile = await FounderProfile.findOneAndUpdate({ user: req.user._id }, data, { new: true });
        } else {
            profile = new FounderProfile(data);
            await profile.save();
        }
        req.user.isProfileComplete = true;
        await req.user.save();
        res.json(profile);
    } catch (err) { res.status(500).send('Server error'); }
});

module.exports = router;
