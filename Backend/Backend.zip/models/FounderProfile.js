const mongoose = require('mongoose');

const founderSchema = new mongoose.Schema({
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },

    startupName: String,
    startupImage: String,
    tagline: String,
    industry: String,
    businessStage: String,
    startupDescription: String,
    problemStatement: String,
    solutionOverview: String,
    usp: String,
    targetMarket: String,
    foundedYear: String,
    startupLocation: String,
    valuation: String,
    fundingRequirement: String,
    equityOffer: String,
    fundingType: String,
    existingInvestors: String,
    businessModel: String,
    useOfFunds: String,
    pitchDeckUrl: String,
    pitchVideoUrl: String,
    productImageUrl: String,
    coFounders: String,
    teamSize: String,
    experienceBackground: String,
    founderLinkedin: String,
    advisors: String,
    businessRegType: String,
    gstNumber: String,
    firmRegistration: String,
    patentDetails: String

}, { timestamps: true });

module.exports = mongoose.model('FounderProfile', founderSchema);
